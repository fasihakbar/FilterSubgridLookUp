// JavaScript source code
function filterSubgrid(gridTypeCode, gridControl, entityParentName, subgridName, viewId, entityRelatedName, viewDisplayName, fetchXML, layoutXML) {
    var LookUp = window["LookUp"] || {};

    LookUp.AddExistingSubgrid = function (gridTypeCode, gridControl) {
        Mscrm.GridRibbonActions.addExistingFromSubGridAssociated(gridTypeCode, gridControl);
        if (Xrm.Page.data.entity.getEntityName() == entityParentName &&
            //gridTypeCode == 2 &&
            typeof gridControl['get_viewTitle'] == 'function') {
            var lookupExistingFieldName = 'lookup_' + subgridName + "_i";
            var inlineBehaviour = document.getElementById(lookupExistingFieldName).InlinePresenceLookupUIBehavior;
            setLookupCustomView(inlineBehaviour, viewId, entityRelatedName, viewDisplayName, fetchXML, layoutXML);
        }
    };

    this.LookUp = LookUp;
    //call this function;
    LookUp.AddExistingSubgrid(gridTypeCode, gridControl);
}

// FUNCTION: setLookupCustomView
//must pass the lookup field control, not field name
//to add custom view to the subgrid (Add existing)
function setLookupCustomView(lookupFieldControl, viewId, entityRelatedName, viewDisplayName, fetchXML, layoutXML) {
    // add the Custom View to the primary contact lookup control      
    lookupFieldControl.AddCustomView(viewId, entityRelatedName, viewDisplayName, fetchXML, layoutXML, true);
}

function getFetchXML() {
    debugger;
    var dot_customer_value = Xrm.Page.getAttribute('dot_customer').getValue()[0].id.replace(/\{|\}/gi, '');
    var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                          "<entity name='dot_party'>" +
                            "<attribute name='dot_name' />" +
                            "<filter type='and'>" +
                              "<condition attribute='dot_customer' operator='eq' uitype='account' value='{" + dot_customer_value + "}' />" +
                            "</filter>" +
                          "</entity>" +
                        "</fetch>";
    return fetchXml;
}

function getObjectTypeCodeNew(entityName) {
    try {
        debugger;
        var lookupService = new RemoteCommand("LookupService", "RetrieveTypeCode");
        lookupService.SetParameter("entityName", entityName);
        var result = lookupService.Execute();

        if (result.Success && typeof result.ReturnValue == "number") {
            return result.ReturnValue;
        }
        else {
            return null;
        }
    }
    catch (ex) {
        throw ex;
    }
}

function getLayoutXML() {
    var targetLookupEntityName = "dot_party";
    var objectTypeCode = getObjectTypeCodeNew(targetLookupEntityName);
    var layoutXml = ("<grid name='resultset' object='" + objectTypeCode + "' jump='fullname' select='1' preview='1' icon='1'>" +
                            "  <row name='result' id='" + targetLookupEntityName + "id'>" +
                            "    <cell name='dot_name' width='200' />" +
                            "  </row>" +
                        "</grid>").toLowerCase();
    return layoutXml;
}

function filterPartiesGrid(gridTypeCode, gridControl) {
    debugger;
    var entityParentName = "dot_document";
    // use randomly generated GUID Id for our new view      
    //--Note : Change following ViewId as per your environment
    var viewId = "{a3408e7d-1059-e811-80de-005056be7607}"; //--- This is actual ID of view which is copied from URL of view in our environment.
    var entityRelatedName = "dot_party";
    var viewDisplayName = "Customers Active Parties";
    var subgridName = "Parties";
    var fetchXml = getFetchXML(); //replace this to your own fetch xml
    // build Grid Layout     
    var layoutXml = getLayoutXML(); //replace this to your own layout example
    if (fetchXml != null) {
        filterSubgrid(gridTypeCode, gridControl, entityParentName, subgridName, viewId, entityRelatedName, viewDisplayName, fetchXml, layoutXml);
    }
}